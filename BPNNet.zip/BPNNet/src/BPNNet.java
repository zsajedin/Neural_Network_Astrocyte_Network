import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;


public class BPNNet {
	
	static int khar=0;
	
	//----------parameters
	static double teta= 0; // threshold of sign function
	static double alpha =0.1;// learning rate
	static double errorThreshold=0.2;
	//-------
	static int epochNumber=10000;
	//general things
	static int numberOfSampleFeatures= 11;
	static int sampleCount=699;
	//----------neurons in each layer
	static int numberNeuronsLayer1= 9;
	static int numberNeuronsLayer2= 8 ;
	static int numberNeuronsLayer3= 2;
	
	Random generator2 = new Random( 19580427 );
	
	//========================-Glia Things
	//static int gliaActivationPeriod=50; //for 50 cycles it'll be active
	static int gliaGetActivatedTime=100;// how many cycles the glia should be seen to be active k times in
	static double gliaIncWeight=1.25;
	static double gliaDecWeight=.75;
	static double gliaThresholdFiring=.75 ;
	static double gliaP=gliaGetActivatedTime*.4*(sampleCount/2); //It shows out of k cycles how many times the nurons should fire to make the corresponding glia active
	static int gliaActiveHiddenNeuron[]=new int[numberNeuronsLayer2];
	//---------------------------------------hidden layer activity saver
	static int hSaver2[][]= new int [sampleCount][numberNeuronsLayer2];
	static int hSaverSilent2[][]= new int [sampleCount][numberNeuronsLayer2];
		//------------------ first layer and thrid layer activity saver
	static int hSaver1[][]= new int [sampleCount][numberNeuronsLayer1];
	static int hSaverSilent1[][]= new int [sampleCount][numberNeuronsLayer1];
		
	static int hSaver3[][]= new int [sampleCount][numberNeuronsLayer3];
	static int hSaverSilent3[][]= new int [sampleCount][numberNeuronsLayer3];
		//------------------		
	static int activeNeurons2[]=new int [numberNeuronsLayer2];
	static int activeNeurons1[]=new int [numberNeuronsLayer1];	
	static int activeNeurons3[]=new int [numberNeuronsLayer3];	
		//--------------
	static int activeSilent2[]=new int [numberNeuronsLayer2];
	static int activeSilent1[]=new int [numberNeuronsLayer1];	
	static int activeSilent3[]=new int [numberNeuronsLayer3];	
	//-------------------it is \mu number of times the neuron fired in k cycle
	static double gliaK1[]= new double [numberNeuronsLayer1];
	static double gliaK2[]= new double [numberNeuronsLayer2];
	static double gliaK3[]= new double [numberNeuronsLayer3];
	//-------------------- the same as above, only keeps the silet times of neuron in k cycle
	static double gliaSilentK1[]= new double [numberNeuronsLayer1];
	static double gliaSilentK2[]= new double [numberNeuronsLayer2];
	static double gliaSilentK3[]= new double [numberNeuronsLayer3];
	//----------to show which glia are active
	static double glia1[]= new double [numberNeuronsLayer1];
	static double glia2[]= new double [numberNeuronsLayer2];
	static double glia3[]= new double [numberNeuronsLayer3];
	//------------sum of input to layer 2 and layer 3-----------
	
	static double y_in2[]= new double[numberNeuronsLayer2];
	static double y_in3[]= new double[numberNeuronsLayer3];
	
	//non modifiable part
	static double layer2[]= new double[numberNeuronsLayer2];
	static double layer3[]= new double [numberNeuronsLayer3];
	//----------------------- weights
	static double w12[][]= new double[numberNeuronsLayer1][numberNeuronsLayer2];
	static double w23[][]= new double[numberNeuronsLayer2][numberNeuronsLayer3];
	static double wBias3[]= new double[numberNeuronsLayer3];
	static double wBias2[]= new double[numberNeuronsLayer2];
	//--------------all input '+1' is for desired output
	 static double nums[][] = new double[sampleCount][numberNeuronsLayer1+1]; 
	 
	 //----------backprop work
	 static double delta3[]=new double[numberNeuronsLayer3];
	 static double delta2[]=new double[numberNeuronsLayer2];
	
	
//-----------------------------------------------------------
	public static void main(String[] args) {
		System.out.println("gliaP="+gliaP);
		// TODO Auto-generated method stub
		try {
			inputFile();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		initilizingWeights(); 
		trainingPerceptron();
		//test();
		printResult();		
	}
	//-------------------------------------Training----------------------
	public static boolean trainingPerceptron(){

		int counter=0;
		
            for(int epoch=0;epoch<epochNumber;epoch++){
		//feedforward part------------------------------------------------------	
		for(int i=0;i<sampleCount;i+=2){// odd indices in sample are for training				
                        //=================== checking glia activation in layer 1
                        for(int input=0;input<numberNeuronsLayer1;input++){
                                 if (nums[i][input]>=gliaThresholdFiring){
                                            gliaK1[input]+=1;
                                            hSaver1[i][input]++;
                                    }
                                  else{if (nums[i][input]<gliaThresholdFiring){
                                            gliaSilentK1[input]+=1;
                                            hSaverSilent1[i][input]++;}}

                            }
                    //--------Signal to layer 2

                            for(int j=0;j<numberNeuronsLayer2;j++){
                                    y_in2[j]=0;
                                    for(int k=0;k<numberNeuronsLayer1;k++){
                                            //System.out.println("&&"+nums[i][k]);
                                            y_in2[j] += nums[i][k]*w12[k][j];
                                    }
                                    y_in2[j] += wBias2[j];
                                    layer2[j]= sigmoid(y_in2[j]);
                                     //System.out.println(y_in2[j]);

                                    //===========================saving active hidden neurons
                                    if(layer2[j]>=gliaThresholdFiring){
                                        hSaver2[i][j]++;
                                    //System.out.println("hi");
                                        gliaK2[j]+=1;
                                            //System.out.println("--hSaver2["+i+"]["+j+"]="+hSaver2[i][j]);
                                    }
                                    else{
                                        if(layer2[j]<gliaThresholdFiring){
                                            //hSaver[i][j]++;
                                            gliaSilentK2[j]+=1;
                                            hSaverSilent2[i][j]++;
                                            //System.out.println("--hSaverSilent2["+i+"]["+j+"]="+hSaverSilent2[i][j]);
                                            }
                                    }
                            }
  //======================================Signal to layer 3
                            for(int j=0;j<numberNeuronsLayer3;j++){
                                    y_in3[j]=0;
                                    for(int k=0;k<numberNeuronsLayer2;k++){
                                            y_in3[j] += layer2[k]*w23[k][j];
                                    }
                                    y_in3[j]+= wBias3[j];
                                    layer3[j]= sigmoid(y_in3[j]);

//===========================saving active hidden neurons
                                    //System.out.println("**i="+i+": layer3="+layer3[j]);
                                    if(layer3[j]>=gliaThresholdFiring){
                                        hSaver3[i][j]++;
                                    //System.out.println(hSaver[i][j]);
                                         gliaK3[j]+=1;
                                    }
                                    else{
                                        if(layer3[j]<gliaThresholdFiring){
                                            hSaverSilent3[i][j]++;
                                            gliaSilentK3[j]+=1;
                                        }
                                    }
                            }
				counter++;
			//------------------------back propagation-------------
				int answerNeuron=0;
				//nums[i][9] is the input shows what the answer is
				if (nums[i][9]==2){ // the output neuron that shows the answer is neuron 1 in output layer and it's value should be 1
					answerNeuron=0;
				}
				else{
					if(nums[i][9]==4){
						answerNeuron=1;
					}
					//else{answerNeuron=2;}
				}
                            //updating the weights from layer 2 to 3   
                             for(int z1=0;z1<numberNeuronsLayer2;z1++){
                                     for(int z2=0;z2<numberNeuronsLayer3;z2++ ){
                                             if (z2==answerNeuron){
                                                     delta3[z2]=(1-layer3[z2])*sigmoid(y_in3[z2])*(1-sigmoid(y_in3[z2]));
                                                     w23[z1][z2]+=alpha*delta3[z2]*layer2[z1];

                                             }
                                             else{
                                                     delta3[z2]=(0-layer3[z2])*sigmoid(y_in3[z2])*(1-sigmoid(y_in3[z2]));
                                                     w23[z1][z2]+=alpha*delta3[z2]*layer2[z1];
                                             }
                                     }

                             }
                            //updating bias of layer 3-------------
                            for (int z3=0;z3<numberNeuronsLayer3;z3++){
                                    if(z3==answerNeuron){
                                           // System.out.println(khar);
                                           // khar++;
                                            wBias3[z3]+=alpha*(1-layer3[z3])*sigmoid(y_in3[z3])*(1-sigmoid(y_in3[z3]));
                                    }
                                    else{
                                    wBias3[z3]+=alpha*(0-layer3[z3])*sigmoid(y_in3[z3])*(1-sigmoid(y_in3[z3]));
                                   }
                            }
                            //updating weights from layer 1 to 2
                            for(int z4=0;z4<numberNeuronsLayer2;z4++){
                                    delta2[z4]=0;
                                    for(int z5=0;z5<numberNeuronsLayer3;z5++){
                                            delta2[z4]+=delta3[z5]*w23[z4][z5];
                                    }
                                    delta2[z4]*=(sigmoid(y_in2[z4])*(1-sigmoid(y_in2[z4])));
                            }

                            for(int z1=0;z1<numberNeuronsLayer1;z1++){
                                    for(int z2=0;z2<numberNeuronsLayer2;z2++ ){
                                            w12[z1][z2]+=alpha*delta2[z2]*nums[i][z1];
                                    }
                            }

                            //updating bias of layer 2					 
                            for(int z5=0;z5<numberNeuronsLayer2;z5++){
                                    wBias2[z5]+=alpha*delta2[z5];
                            }
					 
	}
// ---------------End for samples loop---------------------
			//error=errorCalculation(1);
              
		
		/*	
		System.out.println("gk"+gliaK2[1]);
		(3,1),(2,5),(3,2),(2,4),(2,6),(1,1),(1,6),(1,2),(1,8),(1,7),(1,3),(1,4),(1,5),(2,7),(2,2),(2,8),(2,1),(2,3),(1,9) 	
		*/

                if(epoch%gliaGetActivatedTime==0){// now we should activate glia of very active neurons 	
			if (gliaK3[1]>=gliaP||gliaK2[3]>=gliaP||gliaK2[7]>=gliaP||gliaK1[5]>=gliaP){
				gliaK2[6]=gliaP+1;
				gliaK2[3]=gliaP+1;
				gliaK3[1]=gliaP+1;
				gliaK3[0]=gliaP+1;
				//System.out.println("hi2");
				//------------------------- updating the weights of onter glias in the network here	
			}	
			
			//------------------------------	
			for(int f2=0;f2<numberNeuronsLayer1;f2++){// to make glia active in first layer
				glia1[f2]=0;
				if(gliaK1[f2]>gliaP){
                                    //System.out.println("gliaInc 1 st layer");
					glia1[f2]=1;
					for(int f3=0;f3<numberNeuronsLayer2;f3++){
						w12[f2][f3]*=gliaIncWeight;
                                                
					}
				}	
				gliaK1[f2]=0;
				if(gliaSilentK1[f2]>gliaP){
                                    //System.out.println("gliadec 1 st layer");
					glia1[f2]=-1;
					for(int f3=0;f3<numberNeuronsLayer2;f3++){
						w12[f2][f3]*=gliaDecWeight;
                                                
					}
				}
				gliaSilentK1[f2]=0;
			}
			//-------------network: 2nd neuron in hidden layer is connected to the thrid and 7th one
			
			for(int f2=0;f2<numberNeuronsLayer2;f2++){// to make glia active in 2nd layer
                            //System.out.println("gliaInc 2 nd layer");
				glia2[f2]=0;
				if(gliaK2[f2]>gliaP){
					glia2[f2]=1;
					for(int f3=0;f3<numberNeuronsLayer3;f3++){
						w23[f2][f3]*=gliaIncWeight;
                                                
					}
					
				}	
				gliaK2[f2]=0;
				if(gliaSilentK2[f2]>gliaP){
                                    //System.out.println("gliadec 2 nd layer");
					glia2[f2]=-1;
					for(int f3=0;f3<numberNeuronsLayer3;f3++){
						w23[f2][f3]*=gliaDecWeight;
						
					}
					
				}	
				gliaSilentK2[f2]=0;
			}
		//---------------------------
			for(int f2=0;f2<numberNeuronsLayer3;f2++){// to make glia active in 3rd layer
                            //System.out.println("gliadec 3rd layer");
				glia3[f2]=0;
				if(gliaK3[f2]>gliaP){
					glia3[f2]=1;
                                        
				}
				gliaK3[f2]=0;
				
				if(gliaSilentK3[f2]>gliaP){
					glia3[f2]=-1;
				}
				gliaSilentK3[f2]=0;
			}

		} 
			//-------------------------------------------
	}
            //-------------------------------------End epoch loop----------------------
		System.out.println("Training was done successfully.");
		return true;
			
   }
        //---------------------------------End Training----------------------

	//-----------------------get the input from file and put it in the array nums
		public static void inputFile() throws FileNotFoundException{
			double tempinput[][]=new double[sampleCount][numberOfSampleFeatures];
			
			 File file = new File("dataset.txt");
			 //System.out.println(file.canRead());
		
			Scanner sc = new Scanner(file); 
			for(int j=0;j<sampleCount;j++){
                            String line = sc.nextLine(); 
                            String[] numbers = line.split(","); 
			
                            for(int i=0;i<numberOfSampleFeatures;i++) {
				if(numbers[i].equals("?")){numbers[i]="1";}				
				tempinput[j][i] = Double.parseDouble(numbers[i]); 
			}
			}
			sc.close();	
			
		//-------adapting the input to what we want
			
			for(int j=0;j<sampleCount;j++){	
				for(int i=0;i<numberOfSampleFeatures-1;i++) {
					  nums[j][i]=tempinput[j][i+1];
					//System.out.println("nums["+j+"]["+i+"]="+nums[j][i]);
					if(i != 9){// *.1 is used for normalizing the input for breast cancer data
						nums[j][i] *= 0.1;
					}
					//System.out.println("nums["+j+"]["+i+"]="+nums[j][i]);	
				}
			}
		}

		//------------------------------------------------------------------
		public static double sigmoid(double x){
			double y=0;
			
			y=1/(1+Math.exp(-1*x));
			
			return y;
		}

	//--------------------------------------------------		
		public static boolean initilizingWeights(){
			Random randomGenerator = new Random();
			//---------- weights between layer 1 and 2
			for (int i=0;i<numberNeuronsLayer1;i++){
				for(int j=0;j<numberNeuronsLayer2;j++){
					w12[i][j]= randomGenerator.nextDouble();
				}
			}
			//---------- weights between layer 2 and 3
			for (int i=0;i<numberNeuronsLayer2;i++){
				for(int j=0;j<numberNeuronsLayer3;j++){
					w23[i][j]= randomGenerator.nextDouble();
				}
			}
			//----------- bias of layer 3
		
				for(int j=0;j<numberNeuronsLayer3;j++){
					wBias3[j]= randomGenerator.nextDouble();
				}
			//-----------bias for layer 2
				for (int i=0;i<numberNeuronsLayer2;i++){
						wBias2[i]= randomGenerator.nextDouble();
				}
			//--------------------------
		return true;
		}
	//--------------------------------------------------
		public static double errorCalculation(int t){ //if t==1 it means we just calculate the error for samples used in training
			double error=0;
			double correctCount=0;
			double answer=0;
			int begin=0;// train or test
			//int jump=1;
			if(t==1){begin=0; }
			if(t==3){begin=1; }
					
                        //feedforward part------------------------------------------------------	
                        for(int i=begin;i<sampleCount;i+=2){// odd indices in sample are for training
                        //int i=1;	//***test
                    //--------Signal to layer 2
                            for(int j=0;j<numberNeuronsLayer2;j++){
                                    y_in2[j]=0;
                                    for(int k=0;k<numberNeuronsLayer1;k++){
                                            //System.out.println("&&"+nums[i][k]);
                                            y_in2[j] += nums[i][k]*w12[k][j];
                                    }
                                    y_in2[j] += wBias2[j];
                                    layer2[j]= sigmoid(y_in2[j]);
                                     //System.out.println(y_in2[j]);

                            }
                            //--------Signal to layer 3
                            for(int j=0;j<numberNeuronsLayer3;j++){
                                    y_in3[j]=0;
                                    for(int k=0;k<numberNeuronsLayer2;k++){
                                            y_in3[j] += layer2[k]*w23[k][j];
                                    }
                                    y_in3[j]+= wBias3[j];
                                    layer3[j]= sigmoid(y_in3[j]);

                            }
                            //answer=2;
                            if(layer3[1]>layer3[0]){
                                    answer=4;
                            }
                            else{answer=2;}
                            //System.out.println("answer="+answer+"mums="+nums[i][9]);
                            if(answer==nums[i][9]){
                                    correctCount++;
                            }
			}			
			error= correctCount/(sampleCount/2);
			return error;
		}
//-------------------------------------------------------------------------
	public static void printResult(){
		
		System.out.println("Error of train data="+ errorCalculation(1));
		System.out.println("Error of test Data="+ errorCalculation(3));
		//System.out.println("Error of all Data="+ errorCalculation(2));	
		
		
	}	
		
}
